CREATE DATABASE IF NOT EXISTS `BdunadGrupo1`;

USE `BdunadGrupo1`;

SET foreign_key_checks = 0;

DROP TABLE IF EXISTS `tablagrupo1`;

CREATE TABLE `tablagrupo1` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `codigo` varchar(40) DEFAULT NULL,
  `nombre` varchar(40) DEFAULT NULL,
  `marca` varchar(40) DEFAULT NULL,
  `precio` float DEFAULT NULL,
  `cantidad` int(11) DEFAULT NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;



SET foreign_key_checks = 1;
